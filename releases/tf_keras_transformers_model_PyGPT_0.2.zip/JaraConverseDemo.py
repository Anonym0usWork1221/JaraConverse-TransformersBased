from GlobalVariables import JaraConverseModelConfiguration, VariableParameters
from processing.tokenizer import JaraConverseTokenizer
from layers.JaraConverseModel import JaraConverseModel
from transformers import PreTrainedTokenizerFast
from os import path, environ, listdir
import tensorflow as tf
import keras.models

# force tensorflow to use cpu (comment it if you have gpu available)
# environ['CUDA_VISIBLE_DEVICES'] = '-1'

# turning off machine instructions logs from tensorflow
environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)


class JaraConverseGenerator(tf.Module):
    def __init__(self, tokenizer: PreTrainedTokenizerFast, model: JaraConverseModel):
        super().__init__()
        self.tokenizer: PreTrainedTokenizerFast = tokenizer
        self.jara_converse_model: JaraConverseModel = model

    def __call__(self, sentence: any([str, list[str]]), max_length: int = 100) -> tuple[str, list[str], any]:
        local_sentence: any = sentence
        if isinstance(sentence, str):
            local_sentence = [sentence]

        local_sentence: any = self.tokenizer(
            local_sentence,
            max_length=max_length,
            padding="max_length",
            truncation=True,
            return_tensors="tf"
        ).input_ids

        local_sentence = tf.cast(local_sentence, dtype=tf.int64)
        encoder_input = local_sentence
        start_end = self.tokenizer('', return_tensors="tf").input_ids[0]
        start = tf.cast(start_end[0][tf.newaxis], dtype=tf.int64)  # start tag
        end = tf.cast(start_end[1][tf.newaxis], dtype=tf.int64)  # end tag
        output_array = tf.TensorArray(dtype=tf.int64, size=0, dynamic_size=True)
        output_array = output_array.write(0, start)

        for token_index in tf.range(max_length):  # tf.range() (creates tensors)
            output = tf.transpose(output_array.stack())
            predictions = self.jara_converse_model([encoder_input, output], training=False)
            predictions = predictions[:, -1:, :]
            predicted_id = tf.argmax(predictions, axis=-1)
            output_array = output_array.write(token_index + 1, predicted_id[0])

            if predicted_id[0] == end:
                break

        output = tf.transpose(output_array.stack())
        words: list[str] = [self.tokenizer.decode(ids, skip_special_tokens=True) for ids in
                            tf.squeeze(output).numpy().tolist()]
        results: str = "".join(words)
        self.jara_converse_model([encoder_input, output[:, :-1]], training=False)
        attention_weights: any = self.jara_converse_model.decoder.last_attn_scores
        return results, words, attention_weights


class JaraConverseDemo(object):
    def __init__(self, load_from_checkpoint: bool = False):
        self._tokenizer: PreTrainedTokenizerFast = JaraConverseTokenizer().load_tokenizer()
        self.__load_from_checkpoint: bool = load_from_checkpoint
        self.__model = None
        self.__generator = None

    def load_model(self) -> JaraConverseModel:
        """
        # ISSUE: https://github.com/keras-team/keras-core/issues/855
        # NOTE: There is an issue with loading Keras models in TensorFlow versions 2.13 and 2.14

        model = keras.models.load_model(
            filepath=self._model_path
        )

        # so we are going to build model from scratch and just load trained checkpoints (weights) in our case
        """
        if self.__load_from_checkpoint:
            model: JaraConverseModel = JaraConverseModel(
                num_layers=JaraConverseModelConfiguration.NUMBER_OF_LAYERS.value,
                model_dimensions=JaraConverseModelConfiguration.DIMENSIONALITY_OF_MODEL_EMBEDDINGS.value,
                num_heads=JaraConverseModelConfiguration.NUM_OF_HEADS.value,
                feed_forward_dimensions=JaraConverseModelConfiguration.FF_DIMENSION.value,
                input_vocab_size=self._tokenizer.size,
                target_vocab_size=self._tokenizer.size,
                dropout_rate=JaraConverseModelConfiguration.LEARNING_DROPOUT_RATE.value
            )
            check_point = any(VariableParameters.CHECKPOINT_NAME.value in filename for filename in
                              listdir(path.dirname(path.join(
                                  VariableParameters.CHECKPOINT_DIR.value,
                                  VariableParameters.CHECKPOINT_NAME.value
                              ))))
            if not check_point:
                raise FileNotFoundError("Checkpoints are not found please train the model give the weights file")

            status = model.load_weights(path.join(VariableParameters.CHECKPOINT_DIR.value,
                                                  VariableParameters.CHECKPOINT_NAME.value))
            status.expect_partial()
            return model

        return keras.models.load_model(
            filepath=path.join(VariableParameters.SAVED_MODEL_DIR.value, VariableParameters.SAVED_MODEL_NAME.value)
        )

    def sample_run(self, max_length: int = 100) -> None:
        devices = tf.config.experimental.list_physical_devices('GPU')
        tf.config.experimental.set_memory_growth(device=devices[0], enable=True) if devices else (
            tf.config.experimental.set_visible_devices(devices=[], device_type='GPU'))

        if not self.__model:
            model: JaraConverseModel = self.load_model()
            self.__model = model

        if not self.__generator:
            generator: JaraConverseGenerator = JaraConverseGenerator(
                tokenizer=self._tokenizer, model=self.__model
            )
            self.__generator = generator

        while True:
            try:
                prompt = input("Enter Query: ")
                prompt = prompt[: JaraConverseModelConfiguration.MAX_MODEL_INPUT_SIZE.value].strip()
                result, result_tokens, result_attention_weights = self.__generator(
                    prompt,
                    max_length=max_length
                )
                print("===" * 10 + "UserPrompt" + "===" * 10)
                print(prompt)
                print("\n\n" + "===" * 10 + "Predicted" + "===" * 10)
                print(f"Generated Code:\n\n{result.strip()}")
            except KeyboardInterrupt:
                break


if __name__ == '__main__':
    JaraConverseDemo().sample_run()
