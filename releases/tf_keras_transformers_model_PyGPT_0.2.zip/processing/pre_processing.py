from GlobalVariables import (DataBaseConfiguration, TransformersTokenizerConfiguration, VariableParameters,
                             JaraConverseModelConfiguration, AutoCalculateModelParams)
from datasets import Dataset, DatasetDict, load_from_disk
from transformers import PreTrainedTokenizerFast
from tensorflow import int32, TensorShape, data
from typing import Any
import math


class PreProcessing(object):
    @staticmethod
    def load_and_pre_process_dataset() -> DatasetDict:
        dataset = Dataset.from_sql(
            sql=DataBaseConfiguration.DATABASE_TABLE_NAME.value,
            con=f"sqlite:///{DataBaseConfiguration.TRAINING_DATABASE_PATH.value}"
        )
        raw_datasets = DatasetDict({"train": dataset})
        if DataBaseConfiguration.UNNECESSARY_COLUMNS_IN_DB.value:
            raw_datasets = raw_datasets.remove_columns(
                column_names=DataBaseConfiguration.UNNECESSARY_COLUMNS_IN_DB.value
            )
        num_of_train_examples = len(raw_datasets['train'])
        num_updates_per_epoch = num_of_train_examples // TransformersTokenizerConfiguration.TRAINING_BATCH_SIZE.value
        AutoCalculateModelParams.STEP_PER_TRAINING_EPOC = num_updates_per_epoch

        if DataBaseConfiguration.SPLIT_DATASET.value:
            raw_datasets = raw_datasets['train'].train_test_split(
                test_size=DataBaseConfiguration.SPLIT_PERCENTAGE.value,
                shuffle=DataBaseConfiguration.SHUFFLE_DATASET.value
            )
            num_of_validation_examples = len(raw_datasets['test'])
            num_test_updates_per_epoch = math.ceil(
                num_of_validation_examples / TransformersTokenizerConfiguration.VALIDATION_BATCH_SIZE.value
            )
            AutoCalculateModelParams.STEP_PER_VALIDATION_EPOC = num_test_updates_per_epoch

        # save dataset
        raw_datasets.save_to_disk(
            dataset_dict_path=VariableParameters.CLEANED_DATASET_DIR.value
        )
        return raw_datasets

    @staticmethod
    def load_cleaned_dataset() -> DatasetDict:
        try:
            raw_dataset = load_from_disk(dataset_path=VariableParameters.CLEANED_DATASET_DIR.value)
            num_of_train_examples = len(raw_dataset['train'])
            num_updates_per_epoch = (
                    num_of_train_examples // TransformersTokenizerConfiguration.TRAINING_BATCH_SIZE.value
            )
            AutoCalculateModelParams.STEP_PER_TRAINING_EPOC = num_updates_per_epoch
            if DataBaseConfiguration.SPLIT_DATASET.value:
                num_of_validation_examples = len(raw_dataset['test'])
                num_test_updates_per_epoch = math.ceil(
                    num_of_validation_examples / TransformersTokenizerConfiguration.VALIDATION_BATCH_SIZE.value
                )
                AutoCalculateModelParams.STEP_PER_VALIDATION_EPOC = num_test_updates_per_epoch
            return raw_dataset
        except FileNotFoundError:
            raise FileNotFoundError("Cleaned dataset not found delete the saved states to use default method")

    @staticmethod
    def _tokenize_corpus(element: any, tokenizer: PreTrainedTokenizerFast, max_input_length: int,
                         max_target_length: int) -> dict[str, Any]:
        inputs = element['title']
        outputs = element['code']
        model_inputs = tokenizer(inputs, max_length=max_input_length,
                                 padding="max_length",
                                 truncation=True, return_tensors="tf").input_ids

        model_outputs = tokenizer(outputs, max_length=max_target_length,
                                  padding="max_length", truncation=True,
                                  return_tensors="tf").input_ids
        targ_in = model_outputs[:, :-1]
        targ_out = model_outputs[:, 1:]

        # tuple [(model_inputs, targ_in), targ_out]
        return {"input_ids": model_inputs, "targ_in": targ_in, "targ_out": targ_out}

    def tokenize_code(self,
                      tokenizer: PreTrainedTokenizerFast,
                      dataset: DatasetDict
                      ) -> tuple:
        dataset = dataset.map(self._tokenize_corpus, batched=True,
                              fn_kwargs={
                                  "tokenizer": tokenizer,
                                  "max_input_length": JaraConverseModelConfiguration.MAX_MODEL_INPUT_SIZE.value,
                                  "max_target_length": JaraConverseModelConfiguration.MAX_MODEL_OUTPUT_SIZE.value
                              })
        train_ds = self._get_train_tf_dataset(
            train_dataset=dataset['train'],
            train_seed=TransformersTokenizerConfiguration.TRAINING_SEED.value,
            training_batch_size=TransformersTokenizerConfiguration.TRAINING_BATCH_SIZE.value
        )
        val_ds = self._get_validation_tfdataset(
            eval_dataset=dataset["test"],
            validation_batch_size=TransformersTokenizerConfiguration.VALIDATION_BATCH_SIZE.value
        )
        train_ds = train_ds.map(self._extract_features).repeat()
        val_ds = val_ds.map(self._extract_features).repeat()
        return train_ds, val_ds

    @staticmethod
    def _extract_features(element: any) -> tuple:
        # Convert into (context, targ_in), targ_out (format)
        return (element['input_ids'], element['targ_in']), element['targ_out']

    @staticmethod
    def _get_train_tf_dataset(train_dataset: Dataset, train_seed: int, training_batch_size: int) -> any:
        num_train_examples: int = len(train_dataset)
        train_dataset.set_format(type='tensorflow', columns=['input_ids', 'targ_in', 'targ_out'])
        return_types = {'input_ids': int32, 'targ_in': int32, 'targ_out': int32}
        return_shapes = {
            'input_ids': TensorShape([None]),
            'targ_in': TensorShape([None]),
            'targ_out': TensorShape([None])
        }
        tf_dataset = data.Dataset.from_generator(
            lambda: train_dataset, return_types, return_shapes
        )
        options = data.Options()
        options.experimental_distribute.auto_shard_policy = data.experimental.AutoShardPolicy.OFF
        tf_dataset = tf_dataset.with_options(options)

        ds = (
            tf_dataset.repeat()
            .shuffle(num_train_examples, seed=train_seed)
            .batch(training_batch_size)
            .prefetch(data.AUTOTUNE)
        )
        return ds

    @staticmethod
    def _get_validation_tfdataset(eval_dataset: Dataset, validation_batch_size: int) -> any:
        eval_dataset.set_format(type='tensorflow', columns=['input_ids', 'targ_in', 'targ_out'])
        return_types = {'input_ids': int32, 'targ_in': int32, 'targ_out': int32}
        return_shapes = {
            'input_ids': TensorShape([None]),
            'targ_in': TensorShape([None]),
            'targ_out': TensorShape([None])
        }
        tf_dataset = data.Dataset.from_generator(lambda: eval_dataset, return_types, return_shapes)
        options = data.Options()
        options.experimental_distribute.auto_shard_policy = data.experimental.AutoShardPolicy.OFF
        tf_dataset = tf_dataset.with_options(options)

        ds = (
            tf_dataset.repeat()
            .batch(validation_batch_size)
            .prefetch(data.AUTOTUNE)
        )
        return ds
