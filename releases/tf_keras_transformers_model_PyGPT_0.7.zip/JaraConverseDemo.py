from GlobalVariables import JaraConverseModelConfiguration, VariableParameters
from processing.tokenizer import JaraConverseTokenizer
from layers.JaraConverseModel import JaraConverseModel
from transformers import PreTrainedTokenizerFast
from os import path, environ, listdir
from tensorflow import keras
import tensorflow as tf

# turning off machine instructions logs from tensorflow
environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)


class JaraConverseGenerator(tf.Module):
    def __init__(self, tokenizer: PreTrainedTokenizerFast, model: JaraConverseModel):
        super().__init__()
        self.tokenizer: PreTrainedTokenizerFast = tokenizer
        self.jara_converse_model: JaraConverseModel = model

    def __call__(self, sentence: any([str, list[str]]), max_length: int = 100) -> tuple[str, list[str], any]:
        local_sentence: any = sentence
        if isinstance(sentence, str):
            local_sentence = [sentence]

        local_sentence: any = self.tokenizer(
            local_sentence,
            max_length=max_length,
            padding="max_length",
            truncation=True,
            return_tensors="tf"
        ).input_ids

        local_sentence = tf.cast(local_sentence, dtype=tf.int64)
        encoder_input = local_sentence
        start_end = self.tokenizer('', return_tensors="tf").input_ids[0]
        start = tf.cast(start_end[0][tf.newaxis], dtype=tf.int64)  # start tag
        end = tf.cast(start_end[1][tf.newaxis], dtype=tf.int64)  # end tag
        output_array = tf.TensorArray(dtype=tf.int64, size=0, dynamic_size=True)
        output_array = output_array.write(0, start)

        for token_index in tf.range(max_length):  # tf.range() (creates tensors)
            output = tf.transpose(output_array.stack())
            predictions = self.jara_converse_model([encoder_input, output], training=False)
            predictions = predictions[:, -1:, :]
            predicted_id = tf.argmax(predictions, axis=-1)
            output_array = output_array.write(token_index + 1, predicted_id[0])

            if predicted_id[0] == end:
                break

        output = tf.transpose(output_array.stack())
        words: list[str] = [self.tokenizer.decode(ids, skip_special_tokens=True) for ids in
                            tf.squeeze(output).numpy().tolist()]
        results: str = "".join(words)
        self.jara_converse_model([encoder_input, output[:, :-1]], training=False)
        attention_weights: any = self.jara_converse_model.decoder.last_attn_scores
        return results, words, attention_weights

    def temperature_sampling_steps(self, encoder_input, input_ids, temperature):
        predictions = self.jara_converse_model([encoder_input, input_ids], training=False)
        predictions = predictions[:, -1, :] / temperature
        predicted_ids = tf.random.categorical(predictions, num_samples=1, dtype=tf.int32)
        return predicted_ids

    def temperature_sampling(
            self,
            sentence: any([str, list[str]]),
            temperature: float = 1.0,
            max_length: int = 100
    ):
        if isinstance(sentence, str):
            sentence = [sentence]

        sentence = self.tokenizer(
            sentence,
            max_length=max_length,
            padding="max_length",
            truncation=True,
            return_tensors="tf"
        ).input_ids

        sentence = tf.cast(sentence, dtype=tf.int64)
        encoder_input = sentence
        start_end = self.tokenizer('', return_tensors="tf").input_ids[0]
        start = tf.cast(start_end[0][tf.newaxis], dtype=tf.int64)  # start tag
        input_ids = tf.fill([1, 1], start)
        output_ids = []

        for _ in range(max_length):
            predicted_ids = self.temperature_sampling_steps(
                encoder_input=encoder_input,
                input_ids=input_ids,
                temperature=temperature
            )
            input_ids = tf.concat([input_ids, tf.cast(predicted_ids, tf.int64)], axis=-1)
            output_ids.append(predicted_ids.numpy()[0, 0])

        decoded_output = self.tokenizer.decode(output_ids, skip_special_tokens=True)
        return decoded_output

    def greedy_decoding_steps(self, encoder_input, input_ids):
        predictions = self.jara_converse_model([encoder_input, input_ids], training=False)
        predicted_ids = tf.argmax(predictions[:, -1, :], axis=-1, output_type=tf.int64)
        return predicted_ids

    def greedy_decoding(
            self,
            sentence: any([str, list[str]]),
            max_length: int = 100
    ):
        if isinstance(sentence, str):
            sentence = [sentence]

        sentence = self.tokenizer(
            sentence, max_length=max_length,
            padding="max_length", truncation=True, return_tensors="tf"
        ).input_ids

        sentence = tf.cast(sentence, dtype=tf.int64)
        encoder_input = sentence
        start_end = self.tokenizer('', return_tensors="tf").input_ids[0]
        start = tf.cast(start_end[0][tf.newaxis], dtype=tf.int64)  # start tag
        input_ids = tf.fill([1, 1], start)
        output_ids = []
        for _ in range(max_length):
            predicted_ids = self.greedy_decoding_steps(encoder_input=encoder_input, input_ids=input_ids)
            input_ids = tf.concat([input_ids, predicted_ids[:, tf.newaxis]], axis=-1)
            output_ids.append(predicted_ids.numpy()[0])

        decoded_output = self.tokenizer.decode(output_ids, skip_special_tokens=True)
        return decoded_output


class JaraConverseDemo(object):
    def __init__(self, load_from_checkpoint: bool = False):
        self._tokenizer: PreTrainedTokenizerFast = JaraConverseTokenizer().load_tokenizer()
        self.__load_from_checkpoint: bool = load_from_checkpoint
        self.__model = None
        self.__generator = None

    def load_model(self) -> JaraConverseModel:
        """
        # ISSUE: https://github.com/keras-team/keras-core/issues/855
        # NOTE: There is an issue with loading Keras models in TensorFlow versions 2.13 and 2.14

        model = keras.models.load_model(
            filepath=self._model_path
        )

        # so we are going to build model from scratch and just load trained checkpoints (weights) in our case
        """
        if self.__load_from_checkpoint:
            model: JaraConverseModel = JaraConverseModel(
                num_layers=JaraConverseModelConfiguration.NUMBER_OF_LAYERS.value,
                model_dimensions=JaraConverseModelConfiguration.DIMENSIONALITY_OF_MODEL_EMBEDDINGS.value,
                num_heads=JaraConverseModelConfiguration.NUM_OF_HEADS.value,
                feed_forward_dimensions=JaraConverseModelConfiguration.FF_DIMENSION.value,
                input_vocab_size=self._tokenizer.size,
                target_vocab_size=self._tokenizer.size,
                dropout_rate=JaraConverseModelConfiguration.LEARNING_DROPOUT_RATE.value
            )
            check_point = any(VariableParameters.CHECKPOINT_NAME.value in filename for filename in
                              listdir(path.dirname(path.join(
                                  VariableParameters.CHECKPOINT_DIR.value,
                                  VariableParameters.CHECKPOINT_NAME.value
                              ))))
            if not check_point:
                raise FileNotFoundError("Checkpoints are not found please train the model give the weights file")

            status = model.load_weights(path.join(VariableParameters.CHECKPOINT_DIR.value,
                                                  VariableParameters.CHECKPOINT_NAME.value))
            status.expect_partial()
            return model

        return keras.models.load_model(
            filepath=path.join(
                VariableParameters.SAVED_MODEL_DIR.value, VariableParameters.SAVED_MODEL_NAME.value
            ).__str__()
        )

    def sample_run(self, max_length: int = 100) -> None:
        if not self.__model:
            model: JaraConverseModel = self.load_model()
            self.__model = model

        if not self.__generator:
            generator: JaraConverseGenerator = JaraConverseGenerator(
                tokenizer=self._tokenizer, model=self.__model
            )
            self.__generator = generator

        while True:
            try:
                prompt = input("Enter Query: ")
                prompt = prompt[: JaraConverseModelConfiguration.MAX_MODEL_INPUT_SIZE.value].strip()
                result, result_tokens, result_attention_weights = self.__generator(
                    prompt,
                    max_length=max_length
                )
                print("===" * 10 + "UserPrompt" + "===" * 10)
                print(prompt)
                print("\n\n" + "===" * 10 + "Predicted" + "===" * 10)
                print(f"Generated Code:\n\n{result.strip()}")
            except KeyboardInterrupt:
                break

    def evaluation_execution(self, max_length: int = 100, temperature: float = 0.7) -> None:
        if not self.__model:
            model: JaraConverseModel = self.load_model()
            self.__model = model

        if not self.__generator:
            generator: JaraConverseGenerator = JaraConverseGenerator(
                tokenizer=self._tokenizer, model=self.__model
            )
            self.__generator = generator

        while True:
            try:
                prompt = input("Enter Query: ")
                prompt = prompt[: JaraConverseModelConfiguration.MAX_MODEL_INPUT_SIZE.value].strip()
                result, result_tokens, result_attention_weights = self.__generator(
                    prompt,
                    max_length=max_length
                )
                print("===" * 10 + "UserPrompt" + "===" * 10)
                print(prompt)
                print("\n\n" + "===" * 10 + "Predicted Using Simple generator" + "===" * 10)
                print(f"Generated Code:\n\n{result.strip()}")
                temperature_sample = self.__generator.temperature_sampling(
                    sentence=prompt, max_length=max_length, temperature=temperature
                )
                print("\n\n" + "===" * 10 + f"Predicted Using Temperature Sampling on temp: {temperature}" + "===" * 10)
                print(f"Generated Code:\n\n{temperature_sample.strip()}")
                greedy_sample = self.__generator.greedy_decoding(sentence=prompt, max_length=max_length)
                print("\n\n" + "===" * 10 + f"Predicted Using Greedy Sampling" + "===" * 10)
                print(f"Generated Code:\n\n{greedy_sample.strip()}")
            except KeyboardInterrupt:
                break


if __name__ == '__main__':
    JaraConverseDemo().evaluation_execution(max_length=100, temperature=0.7)
