from GlobalVariables import TransformersTokenizerConfiguration
from transformers import PreTrainedTokenizerFast
from datasets import DatasetDict


class JaraConverseTokenizer(object):
    def __init__(self):
        self._tokenizer_path: str = TransformersTokenizerConfiguration.TOKENIZER_PATH.value

    def load_tokenizer(self) -> PreTrainedTokenizerFast:
        loaded_tokenizer = PreTrainedTokenizerFast.from_pretrained(pretrained_model_name_or_path=self._tokenizer_path)
        loaded_tokenizer.size = len(loaded_tokenizer.vocab)
        return loaded_tokenizer

    @staticmethod
    def _get_training_corpus(dataset: DatasetDict):
        return (
            dataset["train"][i: i + 1000][TransformersTokenizerConfiguration.TRAINING_TOKENIZER_DATA_COLUMN.value]
            for i in range(0, len(dataset["train"]), 1000)
        )

    def train_tokenizer_on_new_dataset(
            self,
            pre_trained_tokenizer: PreTrainedTokenizerFast,
            dataset: DatasetDict
    ) -> PreTrainedTokenizerFast:

        training_corpus = self._get_training_corpus(dataset=dataset)
        trained_tokenizer = pre_trained_tokenizer.train_new_from_iterator(
            text_iterator=training_corpus,
            vocab_size=TransformersTokenizerConfiguration.TRAINING_TOKENIZER_VOCAB_SIZE.value
        )
        trained_tokenizer.size = len(trained_tokenizer.vocab)
        trained_tokenizer.save_pretrained(self._tokenizer_path)
        return trained_tokenizer
